var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["d6f400fd-06aa-4570-a0fb-40fe22173e3d","0e5368ee-dc28-43bd-8bf7-e4eec405bd03","8414ee3f-e159-49c1-bda8-c003cabafb71"],"propsByKey":{"d6f400fd-06aa-4570-a0fb-40fe22173e3d":{"name":"mouse","sourceUrl":"assets/api/v1/animation-library/gamelab/J9BOI5k0GEaOeafJB4nZ_X4G0fvVZZl8/category_animals/mouse_gray.png","frameSize":{"x":300,"y":296},"frameCount":1,"looping":true,"frameDelay":2,"version":"J9BOI5k0GEaOeafJB4nZ_X4G0fvVZZl8","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":300,"y":296},"rootRelativePath":"assets/api/v1/animation-library/gamelab/J9BOI5k0GEaOeafJB4nZ_X4G0fvVZZl8/category_animals/mouse_gray.png"},"0e5368ee-dc28-43bd-8bf7-e4eec405bd03":{"name":"plane","sourceUrl":"assets/api/v1/animation-library/gamelab/vBdsyxwhFjTALJN9ubK2KTLxPJ1.Zdzj/category_vehicles/enemyBlue3.png","frameSize":{"x":103,"y":84},"frameCount":1,"looping":true,"frameDelay":2,"version":"vBdsyxwhFjTALJN9ubK2KTLxPJ1.Zdzj","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":103,"y":84},"rootRelativePath":"assets/api/v1/animation-library/gamelab/vBdsyxwhFjTALJN9ubK2KTLxPJ1.Zdzj/category_vehicles/enemyBlue3.png"},"8414ee3f-e159-49c1-bda8-c003cabafb71":{"name":"shot","sourceUrl":"assets/api/v1/animation-library/gamelab/hhL.oP_nPuW6o2mIjx9eKNKDlAmrLnhb/category_board_games_and_cards/pieceBlack_border01.png","frameSize":{"x":64,"y":64},"frameCount":1,"looping":true,"frameDelay":2,"version":"hhL.oP_nPuW6o2mIjx9eKNKDlAmrLnhb","categories":["board_games_and_cards"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":64,"y":64},"rootRelativePath":"assets/api/v1/animation-library/gamelab/hhL.oP_nPuW6o2mIjx9eKNKDlAmrLnhb/category_board_games_and_cards/pieceBlack_border01.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


var score = 0;
var ball1;
var ball2;
var ball3;
var canon;
var shot;
canon = createSprite(200,360,20,20);
canon.setAnimation("plane");
canon.scale= 0.8;
ball1 = createSprite(50,145,10,10);
ball1.setAnimation("mouse");
ball1.scale= 0.2;
ball2 = createSprite(200,65,10,10);
ball2.setAnimation("mouse");
ball2.scale= 0.2;
ball3 = createSprite(350,225,10,10);
ball3.setAnimation("mouse");
ball3.scale= 0.2;
shot = createSprite(196,356,10,10);
shot.setAnimation("shot");
shot.scale= 0.3;
ball1.setVelocity(10, 0);
ball2.setVelocity(-10, 0);
ball3.setVelocity(10, 0);








function draw() {
 background("white") ;
 createEdgeSprites();
 ball1.bounceOff(rightEdge);
 ball2.bounceOff(rightEdge);
 ball3.bounceOff(rightEdge);
 ball1.bounceOff(leftEdge);
 ball2.bounceOff(leftEdge);
 ball3.bounceOff(leftEdge);
 
 
 
 
 textSize("15");
 text("SCORE: " + score,170,20);

 
 
    
if (keyWentDown("space")) {
  
   shot.velocityY = -10;
   
 }
 if (keyWentDown("space")) {
    shot.x=canon.x;
  shot.y=canon.y;
    
  }
 
if (score===3) {
 
 textSize(18);
fill("maroon");
text("YOU WIN", 120, 180); 
}


  


  

if (keyDown("RIGHT_ARROW")) {
   canon.x = canon.x + 5;
   
 }
 if (keyDown("LEFT_ARROW")) {
   canon.x = canon.x - 5;
   
 }
 
 if (shot.isTouching(ball1)) {
    ball1.destroy();
    score= score+1;
    
  }
  if (shot.isTouching(ball2)) {
    ball2.destroy();
    score= score+1;
  }
  if (shot.isTouching(ball3)) {
    ball3.destroy();
    score= score+1;
  }

 
 
 drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
